# Arnav — 60-second technical demo explanation

> My part of the Lunar South Pole Mission Planner is the lunar terrain model. We selected three representative published points near the lunar south pole and use NASA's LOLA digital elevation models to extract local elevation and slope. More importantly, we calculate a 360-degree terrain horizon profile: for each compass direction, we sample the surrounding topography, account for lunar curvature, and record the highest angle at which terrain could block a line of sight.
>
> My module outputs one standardized JSON profile per site, along with a horizon CSV and plot. Madhav combines those terrain angles with SPICE Sun/Earth positions to determine terrain-aware visibility. Felix uses the exact same angular horizon to draw what an observer sees on the Moon, and Rajit serves the results through the API.
>
> Since illumination and Earth line of sight are sensitive to local topography and observer height, we document our coordinate frame, terrain resolution and DEM coverage. A good landing date at one site may still be a poor date a few kilometers away. The terrain profile lets the planner test those scenarios with consistent underlying geometry.

## When showing a 7-day mission delay

1. Display one site and its static terrain horizon. Emphasize that the terrain **does not change** when the mission date changes.
2. Madhav/Felix move the Sun and Earth tracks to the original landing date, then the delayed date.
3. Show how the paths cross the same horizon at different times, changing sunlight and Earth visibility windows.
4. Compare with the second site, where the skyline differs.
5. Mention that geometric visibility is necessary but insufficient for guaranteed solar power or communications.

## If a judge asks about accuracy

- Topography: NASA LRO/LOLA high-resolution 5 m site DEMs plus the 80 m regional product to extend horizon coverage.
- Angular geometry: Moon-centered surface positions, local east/north/up basis, maximum terrain angle at each azimuth; full spherical curvature.
- Caveats: DEM interpolation, 1° azimuth spacing, finite ray sample spacing, 120 km default radial limit, 2 m observer height, reference-frame alignment with SPICE.
- Validation: regression tests on synthetic terrain, plus mandatory cross-checks against real NASA elevation and slope data and independent Sun/Earth ephemerides before any claim of operational accuracy.
- Synthetic test plot is an **engineering software check only**, never part of the evidence for a real lunar visibility claim.
