"""Example of safe use by Madhav/Felix/Rajit; no SPICE calculations included."""
import json
import numpy as np
from science.terrain.geometry import visibility


def terrain_visibility(json_path, azimuth_deg, elevation_deg):
    result = json.load(open(json_path, encoding='utf-8'))
    if result['status'] != 'geotiff_calculated_pending_validation':
        raise ValueError('Synthetic/schema data must not be passed as mission terrain')
    if not result['quality']['horizon_samples_are_complete']:
        return None  # insufficient terrain evidence to conclude clear line of sight
    profile = sorted(result['terrain_horizon'], key=lambda item: item['azimuth_deg'])
    heights = [np.nan if row['elevation_deg'] is None else row['elevation_deg'] for row in profile]
    return visibility(elevation_deg, azimuth_deg, heights)
